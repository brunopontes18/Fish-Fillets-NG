# Projeto de Programação Orientada para Objetos - Relatório
Este projeto implementa um jogo 2D baseado em grelha(10x10) onde dois peixes — **SmallFish** e **BigFish** — devem navegar um conjunto de níveis repletos de obstáculos, objetos móveis e perigos.  
O objetivo é levar **ambos os peixes até à saída** sem morrerem.
O jogo segue uma lógica física simples (gravidade, empurrões laterais, interações entre objetos) e introduz ainda elementos avançados como inimigos móveis, explosões e regras de comportamento específicas para cada tipo de objeto.

---

##  Mecânicas principais do jogo

### Peixes
**SmallFish**  
  - É o peixe mais ágil porém mais frágil.  

Pode:
  - Atravessar **Parede com Buraco** (`ParedeBuraco`).
  - Atravessar **Armadilha** sem morrer.
  - Empurrar **apenas objetos leves** (ex.: Taça).
  - Suportar **no máximo 1 objeto leve** (se tentar suportar mais → Game Over).
Não pode:
  - Suportar objetos pesados.
  - Ficar por cima de bombas, boias, taças, etc., exceto quando as regras de suporte o permitem.
Morre se:
  - Um objeto **pesado** cair em cima dele (Pedra, Âncora, etc.).
  - Entrar na área de explosão de uma **Bomba**.
  - Tocar num **Caranguejo**.  

**BigFish**  
  É o peixe mais forte.

Pode:
  - Empurrar vários objetos leves ou pesados na **horizontal**.
  - Empurrar **um só objeto** na **vertical** (leve ou pesado).
  - Mover a **Âncora** horizontalmente **apenas 1 vez**; a seguir fica imóvel.
  - Matar **Caranguejos** ao contactar com eles.
Não atravessa **Parede com Buraco**.
Morre se:
  - Entrar numa **Armadilha**.
  - For esmagado pelo efeito de gravidade (objeto pesado a cair sobre ele).

---

### Objetos
 ____________________________________________________________________________________________________________________________________________________________________
  Objeto (Letra)          |   Tipo    |                               Comportamento                                                                                   
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
         **Taça (C)**     |   Leve    | Pode ser empurrada nas 4 direções. Atravessa parede com buraco.
         **Pedra (R)**    |   Pesado  | Empurrável. Ao mover horizontalmente pela primeira vez, caso não tenha nada na cela imediatamente acima gera um Caranguejo.
         **Âncora (A)**   |   Pesado  | Pode ser movida **1 posição** horizontal pelo BigFish; depois fica imóvel. 
         **Bomba (b)**    |   Leve    | Explode ao cair e colidir; destrói 5 células (centro + 4 adjacentes).
         **Boia (P)**     |   Leve    | Tenta subir (flutuabilidade); só o BigFish a pode empurrar para baixo.
      **Caranguejo (c)**  |   Leve    | É um **Inimigo**! Move-se horizontalmente de forma aleatória sempre que um peixe se mexe.
      **Armadilha (T)**   |   Fixo    | Mata o BigFish; SmallFish atravessa por cima sem morrer.
        **Tronco (Y)**    |   Fixo    | Destruído se um objeto pesado cair por cima.
        **Parede (W)**    |   Fixo    | Apenas sofre alterações com explosão da bomba.
     **ParedeBuraco (X)** |   Fixo    | Pode ser atravessada pela Taça e pelo SmallFish (e possivelmente Caranguejo).
  **SteelHorizontal (H)** |   Fixo    | Tubo de aço horizontal; suporte sólido.
    **SteelVertical (V)** |   Fixo    | Tubo de aço vertical; suporte sólido.
         **Exit (E)**     |   Fixo    | Saída do nível; ambos os peixes têm de lá chegar.
        **Water (' ')**   |   Fundo   | Ocupa todas as células livres; não bloqueia nada.
----------------------------------------------------------------------------------------------------------------------------------------------------------------------


### Caranguejo (Inimigo)

- Criado **automaticamente** na primeira vez que uma Pedra (`Rock`) é movida na horizontal, desde que a célula imediatamente acima esteja livre (apenas Water).
- Move-se **uma casa** para a esquerda ou direita de forma aleatória sempre que um peixe se move.
- Sofre gravidade.
- Interações:
  - Tocar no SmallFish → SmallFish morre (Game Over).
  - Tocar no BigFish → Caranguejo morre.
  - Tocar numa Armadilha → Caranguejo morre.

---

## Gravidade

A gravidade é aplicada em cada “tick” do jogo (`applyGravity()` na classe `Room`)

Atua sobre Taça, Pedra, Âncora, Bomba, Boia, Caranguejo (e outros móveis).
A queda é **gradual** (quadrado a quadrado).

Objetos caem enquanto:
  - a célula abaixo for **Water**, ou
  - outras condições específicas o permitirem (por ex., ParedeBuraco para Taça/SmallFish).

Se um objeto pesado aterrar em cima de:
  - **Tronco** → Tronco é destruído.
  - **Peixe** → Game Over.

Bombas:
  - Marcam estado de “em queda”.
  - Se estavam a cair e colidem com algo sólido → explodem.
  - Explosão destrói objetos (exceto Water) na célula da bomba e nas 4 adjacentes.

---

## Highscores

O jogo guarda automaticamente:
- Nome do jogador
- Tempo total até terminar todos os níveis
- Número total de movimentos (jogadas com teclas de direção)

Guardado em: highscores.txt

Formato de cada linha: nome;tempoEmMilissegundos;numeroDeMovimentos

No final de uma run, é apresentada uma tabela com os Top 10 highscores, ordenados por:
-Menor tempo,
-Menor número de movimentos (desempate).

---

## Como adicionar novos níveis 
Criar novos níveis - Para adicionar um nível, basta criar um ficheiro roomX.txt dentro da pasta "/rooms".

---
## Considerações
1. Gravidade manual (Room.applyGravity()) - A gravidade é tratada de forma explícita, percorrendo objetos móveis e verificando a célula abaixo. Isto dá mais controlo e torna o comportamento previsível e fácil de testar.
2. Peixes como Singletons - SmallFish e BigFish são singletons, pois só existe um de cada tipo. Simplifica a lógica de mudança de níveis e reinícios.
3. Âncora com movimento limitado - A Ancora tem um boolean movedHorizontally que impede movimentação lateral após a primeira vez, criando puzzles mais interessantes.
4. Bomba e Explosão controlada - A bomba só explode se tiver estado em queda (falling == true) e colidir. A explosão atinge apenas o centro e os quatro vizinhos (cima, baixo, esquerda, direita).
5. Entrada sequencial na saída (Exit) - Quando um peixe entra no Exit, é removido da grelha (posição passa a null). Isto permite que o outro peixe ocupe a mesma célula mais tarde, sem conflitos.
6. Caranguejo reativo - Os Caranguejos não se movem em "tempo real"; apenas em resposta a movimentos de peixes. Isto reduz caos visual e torna o jogo mais estratégico.
7. water como "fundo" do tabuleiro - Cada célula da grelha tem sempre pelo menos um Water, o que simplifica o desenho e evita NPEs ao desenhar o nível.

---

## Como correr

Abrir o projeto numa IDE Java (Eclipse, IntelliJ(os dois falados em aula)).

Verificar que:
-existe a pasta rooms com os ficheiros room0.txt, room1.txt, etc.
-a pasta images contém as imagens requeridas pelos getName() dos objetos.

Executar a classe: pt.iscte.poo.game.Main

Controlos:

↑ ↓ ← → – mover o peixe ativo

SPACE – alternar entre SmallFish e BigFish

R – reiniciar o nível atual

---

## Decisões de Design / Considerações

- Peixes como Singletons (SmallFish.getInstance(), BigFish.getInstance()): garante que existe apenas um de cada tipo em todo o jogo, simplificando resets e mudança de níveis.
- Gravidade centralizada em Room.applyGravity(): permite controlar quedas de forma consistente e gradual, evitando que cada objeto implemente a sua própria gravidade.
- Parede com buraco tratada explicitamente: apenas certos objetos (Taça, SmallFish e eventualmente Caranguejo) podem atravessá-la, o que é verificado no código de movimento e gravidade.
- Âncora com movimento lateral único: através de um boolean movedHorizontally em Ancora, reforçando o caráter de “objeto especial” para puzzles.
- Inimigo reativo (Caranguejo): só se movimenta quando os peixes se mexem, evitando caos visual e tornando o comportamento mais previsível.
- Preenchimento do tabuleiro com Water: todas as células têm sempre pelo menos um objeto (Water), o que simplifica desenho gráfico e evita null.
- Sistema de fim de nível e saída (Exit): quando um peixe atinge a saída, é removido da grelha e a sua posição passa a null, permitindo o outro peixe ocupar a mesma célula mais tarde.

---

## Objetivo Final

Levar os dois peixes à saída em cada nível, explorando: gravidade, empurrões laterais e verticais, objetos pesados/leves, inimigos (Caranguejos), armadilhas e paredes especiais, com o menor número de movimentos e tempo possíveis.

---
## Estrutura do Código

### Pacotes principais

/pt/iscte/poo/game
    ├── GameEngine.java   // Lógica do jogo, níveis, input, highscores
    ├── Room.java         // Representação da grelha, objetos, gravidade, explosões
    └── Main.java         // Ponto de entrada

/pt/iscte/poo/objects
    ├── GameObject.java       // Super-classe de todos os objetos
    ├── GameCharacter.java    // Super-classe de peixes (personagens jogáveis)
    ├── SmallFish.java
    ├── BigFish.java
    ├── Rock.java
    ├── Ancora.java
    ├── Bomba.java
    ├── Boia.java
    ├── Caranguejo.java
    ├── Armadilha.java
    ├── ParedeBuraco.java
    ├── Exit.java
    ├── Taca.java
    ├── Tronco.java
    ├── Wall.java
    ├── SteelHorizontal.java
    ├── SteelVertical.java
    └── Water.java

/pt/iscte/poo/gui
    ├── ImageGUI.java     // Interface gráfica
    └── ImageTile.java

/pt/iscte/poo/utils
    ├── Point2D.java
    ├── Vector2D.java
    └── Direction.java

/pt/iscte/poo/observer
    ├── Observed.java
    └── Observer.java

## Diagrama UML

![Diagrama UML](DiagramaUML.png)