package objects;

import pt.iscte.poo.game.Room;

public class Ancora extends GameObject {
	
	//Indica se a âncora já foi movida horizontalmente pelo BigFish.
	//Uma vez movida, torna-se imóvel para o resto do nível.
	private boolean movedHorizontally = false;

	public Ancora(Room room) {
		super(room);
	}

	@Override
	public String getName() {
		return "anchor";
	}

	@Override
	public int getLayer() {
		return 1;
	}
	
	@Override
	public boolean isMovable() {
		return true;
	}
	
	@Override
	public boolean isHeavy() {
		return true;
	}
	
	@Override
	public boolean isSolid() {
		return true;
	}
	
	//Verifica se a Âncora já foi movida uma vez horizontalmente
	public boolean hasMovedHorizontally() {
		return movedHorizontally;
	}
	
	//Marca como ja ter sido movida a única vez que o pode ser no nível
	public void markMovedHorizontally() {
		this.movedHorizontally = true;
	}

}