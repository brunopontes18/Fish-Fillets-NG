package objects;

import pt.iscte.poo.game.Room;

public class Armadilha extends GameObject {

	public Armadilha(Room room) {
		super(room);
	}

	@Override
	public String getName() {
		return "trap";
	}

	@Override
	public int getLayer() {
		return 1;
	}

	@Override
	public boolean isMovable() {
		return false;
	}
	
	//Objeto pesado
	@Override
	public boolean isHeavy() {
		return true;
	}
	
	@Override
	public boolean isSolid() {
		return true;
	}
	
}