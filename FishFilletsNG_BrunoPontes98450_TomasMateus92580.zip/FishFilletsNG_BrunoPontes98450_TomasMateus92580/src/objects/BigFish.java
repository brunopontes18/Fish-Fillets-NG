package objects;

import pt.iscte.poo.utils.Point2D;
import java.util.ArrayList;
import java.util.List;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Vector2D;

public class BigFish extends GameCharacter {
	
	//Instância única (singleton)
	private static BigFish bf = new BigFish(null);
	
	//Liste de objetos a suportar
	private List<GameObject> supportedObject = new ArrayList<>();
	
	//Construtor privado
	private BigFish(Room room) {
		super(room);
	}

	//Instânciia única do BigFish
	public static BigFish getInstance() {
		return bf;
	}
	
	//Nome da imagem associada ao BigFish
	@Override
	public String getName() {
		return "bigFishLeft";
	}
	
	//Camada de desenho do BigFish
	@Override
	public int getLayer() {
		return 1;
	}
	
	//Tratamento da morte do BiFish. Reinicia o nível e limpa os objetos suportados
	private void die() {
		supportedObject.clear();
		if (getRoom() != null && getRoom().getEngine() != null)
			getRoom().getEngine().restartLevel();
	}
	
	//Limpa a lista de objetos suportados
	public void clearSupported() {
		supportedObject.clear();
	}
	
	//Movimento do BigFish
	@Override
	public void move(Vector2D dir) {
	    if (dir == null) 
	    	return;
	    
	    if (getPosition() == null || getRoom() == null) 
	    	return;

	    Point2D current = getPosition();
	    Point2D dest = current.plus(dir);
	    Room room = getRoom();

	    if (dest.getX() < 0 || dest.getY() < 0 || dest.getX() >= 10 || dest.getY() >= 10)
	        return;

	    List<GameObject> destObjs = room.getObjectsAt(dest);
	    
	    //Mata o caranguejo caso toque nele
	    for (GameObject o : destObjs) {
	        if (o instanceof Caranguejo) {
	            room.removeObject(o);
	            break;
	        }
	    }

	    //Se entrar numa armadilha → morte 
	    for (GameObject o : destObjs) {
	        if (o instanceof Armadilha) {
	            if (getRoom().getEngine() != null) {
	                getRoom().getEngine().showGameOverAndRestart();
	            }
	            return;
	        }
	    }

	    //Verificação da sobrecarga de peso. Mais que 1 pesado → morte 
	    int heavyCount = 0;
	    for (GameObject g : supportedObject)
	        if (g.isHeavy()) heavyCount++;
	    if (heavyCount > 1) {
	        if (getRoom().getEngine() != null) 
	        	getRoom().getEngine().showGameOverAndRestart();
	        return;
	    }
    
	    //Movimento horizontal
	    if (dir.getX() != 0) {
	    	//Caso especial, caso hajam âncoras no destino
	    	List<Ancora> anchorsInDest = new ArrayList<>();
	    	for (GameObject o : destObjs) {
	    		if (o instanceof Ancora) {
	    			anchorsInDest.add((Ancora)o);
	    		}
	    	}
	    	
	    	//Se houverem âncoras na casa de destino
	    	if (!anchorsInDest.isEmpty()) {
	    		//Não pode empurrar uma âncora que ja tenha sido empurrada horizontalmente
	    		for (Ancora a : anchorsInDest) {
	    			if (a.hasMovedHorizontally()) {
	    				return;
	    			}
	    		}
	    		
	    		//Se houver mais que uma âncora não empurra
	    		if (anchorsInDest.size() > 1) {
	    			return;
	    		}
	    		
	    		Ancora a = anchorsInDest.get(0);
	    		
	    		//Destino da âncora
	    		Point2D anchorDest = dest.plus(dir);
	    		if (anchorDest.getX() < 0 || anchorDest.getY() < 0 || anchorDest.getX() >= 10 || anchorDest.getY() >= 10)
	    			return;
	    		
	    		//Casa para onde a âncora vai tem de ser água
	    		List<GameObject> anchorDestObjs = room.getObjectsAt(anchorDest);
	    		for (GameObject ao : anchorDestObjs) {
	    			if (!(ao instanceof Water)) {
	    				return; 
	    			}
	    		}
	    		
	    		//Empurra âncora uma casa e marca que já foi movida
	    		a.setPosition(anchorDest);
	    		a.markMovedHorizontally();
	    		
	    		setPosition(dest);
	    		//Se houver caranguejo no destino mata-o
	    		killKrabAt(dest, room);
	    		
	    		//Ao mover horizontalmente, os objetos suportados afundam se possível
	    		if (!supportedObject.isEmpty()) {
	    			for (GameObject s : new ArrayList<>(supportedObject)) {
	    				Point2D sp = s.getPosition();
	    				Point2D below = new Point2D(sp.getX(), sp.getY() + 1);
	    				if (below.getY() < 10) {
	    					boolean canSink = true;
	    					for (GameObject o : room.getObjectsAt(below)) {
	    						if (o.isSolid() || o instanceof GameCharacter) {
	    							canSink = false;
	    							break;
	    						}
	    					}
	    					if (canSink) s.setPosition(below);
	    				}
	    			}
	    			supportedObject.clear();
	    		}
	    		
	    		room.updateGUI();
	    		return;
	    	}
	    	
	    	//Movimento horizontal sem caso especial
	    	//Bloqueia se encontrar sólido ou parede com buraco
	        for (GameObject o : destObjs) {
	            if (o instanceof Exit || o instanceof Caranguejo) 
	            	continue;
	            if (o.isSolid() || o instanceof ParedeBuraco) {
	                return;
	            }
	        }

	        //Constrói a cadeia de objetos que serão empurrados na horizontal
	        List<GameObject> chain = new ArrayList<>();
	        Point2D cursor = dest;
	        boolean blocked = false;

	        while (true) {
	            List<GameObject> here = room.getObjectsAt(cursor);
	            boolean foundMovable = false;

	            for (GameObject o : here) {
	                if (o instanceof Water || o instanceof Exit || o instanceof Caranguejo)
	                    continue;
	                if (o.isMovable()) {
	                    foundMovable = true;
	                    chain.add(o);
	                }
	                else if (o.isSolid() || o instanceof ParedeBuraco) {
	                    blocked = true;
	                    break;
	                } else {
	                    blocked = true;
	                    break;
	                }
	            }
	            if (blocked)
	            	break;
	            if (!foundMovable) 
	            	break;
	            
	            //Avança o cursor ao longo da cadeia
	            cursor = cursor.plus(dir);
	            if (cursor.getX() < 0 || cursor.getY() < 0 || cursor.getX() >= 10 || cursor.getY() >= 10) {
	                blocked = true;
	                break;
	            }
	        }

	        if (blocked) return;
 
	        //Move a cadeia na ordem inversa, para não colidir consigo própria
	        for (int i = chain.size() - 1; i >= 0; i--) {
	            GameObject o = chain.get(i);
	            Point2D newPos = o.getPosition().plus(dir);
	            o.setPosition(newPos);

	            //Se a Rock for empurrada na horizontal, pode gerar um caranguejo em cima, caso a casa de cima não esteja ocupada
	            if (dir.getY() == 0 && o instanceof Rock) {
	                Rock r = (Rock) o;
	                if (!r.hasKrabSpawned()) {
	                    Point2D krabPos = new Point2D(newPos.getX(), newPos.getY() - 1);
	                    if (krabPos.getY() >= 0) {
	                        List<GameObject> above = room.getObjectsAt(krabPos);
	                        boolean free = true;
	                        for (GameObject ob : above) {
	                            if (!(ob instanceof Water)) { 
	                            	free = false; 
	                            	break; 
	                            }
	                        }
	                        if (free) {
	                            Caranguejo c = new Caranguejo(room);
	                            c.setPosition(krabPos);
	                            room.addObject(c);
	                            r.setKrabSpawned(true);
	                        }
	                    }
	                }
	            }
	        }

	        setPosition(dest);
	        killKrabAt(dest,room);

	        //Ao mover horizontalmente, tenta afundar objetos suportados
	        if (!supportedObject.isEmpty()) {
	            for (GameObject s : new ArrayList<>(supportedObject)) {               
	                Point2D sp = s.getPosition();
	                Point2D below = new Point2D(sp.getX(), sp.getY() + 1);
	                if (below.getY() < 10) {      
	                    boolean canSink = true;
	                    for (GameObject o : room.getObjectsAt(below)) {
	                        if (o.isSolid() || o instanceof GameCharacter) {
	                            canSink = false;
	                            break;
	                        }
	                    }
	                    if (canSink) s.setPosition(below);
	                }
	            }
	            supportedObject.clear();
	        }

	        room.updateGUI();
	        return;
	    }

	    //Movimento vertical
	    if (dir.getY() != 0) {
	    	//Bloqueios verticais (não atravessa parede com buraco nem âncora)
	        for (GameObject o : destObjs) {
	        	if (o instanceof Exit || o instanceof Caranguejo) 
	        		continue;
	        	if (o instanceof Ancora)
	        		return;
	            if (!o.isMovable() && o.isSolid()) 
	            	return;
	            if (o instanceof ParedeBuraco) 
	            	return; 
	        }

	        //Conta quantos objetos móveis existem no destino(ignorando âncora)
	        int movableCount = 0;
	        GameObject movable = null;
	        for (GameObject o : destObjs) {
	            if (o.isMovable() && !(o instanceof Ancora)) {
	                movableCount++;
	                movable = o;
	            }
	        }
	        
	        //BigFish empurra no máximo 1 objeto em vertical
	        if (movableCount > 1) {
	            return; 
	        }

	        if (movableCount == 1) {
	            Point2D pushDest = dest.plus(dir);
	            if (pushDest.getX() < 0 || pushDest.getY() < 0 || pushDest.getX() >= 10 || pushDest.getY() >= 10)
	                return;
	            for (GameObject o : room.getObjectsAt(pushDest)) {
	            	
	            	//Pode atravessar parede buraco com taça ou caranguejo
	                if (o instanceof ParedeBuraco && (movable instanceof Taca || movable instanceof Caranguejo)) {
	                    continue;
	                }
	                //Não empurra objetos para cima de outros móveis
	                if (o.isMovable()) {
	                    return;
	                }
	                //Bloqueio por objetos sólidos ou personagens
	                if (o.isSolid() || o instanceof GameCharacter) {
	                    return;
	                }
	            }
	            
	            movable.setPosition(pushDest);
	            setPosition(dest);
	            killKrabAt(dest, room);
	            
	            //Se estiver a suportar objetos, mantém-nos na mesma posição que o peixe
	            if (!supportedObject.isEmpty()) {
	                for (GameObject s : new ArrayList<>(supportedObject)) {
	                    s.setPosition(dest);
	                }
	                supportedObject.clear();
	            }
	            room.updateGUI();
	            return;
	        } else {
	        	//Não há objeto móvel no destino → tentar movimento simples
	            if (room.canMoveTo(dest)) {
	                setPosition(dest);
	                killKrabAt(dest, room);
	                if (!supportedObject.isEmpty()) {
	                    for (GameObject s : new ArrayList<>(supportedObject)) {
	                        s.setPosition(dest);
	                    }
	                    supportedObject.clear();
	                }
	                room.updateGUI();
	            }
	            return;
	        }
	    }
	}
	
	//Remove qualquer caranguejo na posição dada
	private void killKrabAt(Point2D p, Room room) {
        List<GameObject> objs = room.getObjectsAt(p);
        for (GameObject o : new ArrayList<>(objs)) {
            if (o instanceof Caranguejo) {
                room.removeObject(o);
            }
        }
    }
	
	//Adiciona um objeto à lista de objetos suportados pelo BigFish
	public boolean addSupported(GameObject obj) {
		if(obj == null) return false;
		supportedObject.add(obj);
		int heavyCount = 0; 
		for (GameObject g: supportedObject) 
			if (g.isHeavy()) heavyCount++;
		//Se, após adicionar, o número de objetos pesados suportados for superior a 1 → morte 
		if (heavyCount > 1) {
			die();
			return false;
		}
		return true;
	}
}