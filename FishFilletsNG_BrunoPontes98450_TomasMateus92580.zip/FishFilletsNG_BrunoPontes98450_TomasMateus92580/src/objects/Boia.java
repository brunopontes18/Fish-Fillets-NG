package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Point2D;
import pt.iscte.poo.utils.Vector2D;

public class Boia extends GameObject implements Tickable{

	public Boia(Room room) {
		super(room);
	}
	
	@Override
	public String getName() {
		return "buoy";
	}
	
	@Override
	public int getLayer() {
		return 1;
	}
	
	@Override
	public boolean isMovable() {
		return true;
	}
	
	@Override
	public boolean isHeavy() {
		return false;
	}
	
	@Override
	public boolean isSolid() {
		return false;
	}
	
	//Comportamento automático da boia
	@Override
    public void tick() {
        if (getPosition() == null || getRoom() == null) return;
        
        Point2D pos = getPosition();
        Point2D above = new Point2D(pos.getX(), pos.getY() - 1);
        
        //Se já está no topo da grelha não pode flutuar
        if (above.getY() < 0) return;

        boolean canFloat = true;

        //Verifica se pode subir
        for (GameObject o : getRoom().getObjectsAt(above)) {
            //Bloqueios: sólidos, peixes ou qualquer coisa que não seja água
        	if (o.isSolid() || o instanceof GameCharacter || !(o instanceof Water)) {
                canFloat = false;
                break;
            }
        }
        
        
        if (canFloat) {
            setPosition(above);
            getRoom().updateGUI();
        }
    }

	//Verifica se um peixe pode empurrar a boia na direção dada
    public boolean canBePushedBy(GameCharacter fish, Vector2D dir) {
    	
    	//Peixe pequeno nunca pode empurrar a boia para cima
        if (dir.getY() > 0 && !(fish instanceof BigFish)) {
            return false; 
        }

        return true; 
    }
}