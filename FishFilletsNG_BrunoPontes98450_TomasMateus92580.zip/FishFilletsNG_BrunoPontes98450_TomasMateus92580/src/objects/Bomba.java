package objects;

import pt.iscte.poo.game.Room;

public class Bomba extends GameObject {

	private boolean falling = false;
	
	public Bomba(Room room) {
		super(room);
	}

	@Override
	public String getName() {
		return "bomb";
	}

	@Override
	public int getLayer() {
		return 1;
	}

	@Override
	public boolean isMovable() {
		return true;
	}
	
	@Override
	public boolean isHeavy() {
		return false;
	}
	
	@Override
	public boolean isSolid() {
		return false;
	}
	
	public boolean wasFalling() {
        return falling;
    }
	
	public void markFalling() {
        falling = true;
    }
	
	public void resetFalling() {
		falling = false;	
	}
	
}