package objects;

import java.util.Random;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Point2D;

public class Caranguejo extends GameObject implements Tickable{ 
	
	private static final Random rnd = new Random();

	public Caranguejo(Room room) {
		super(room);
	}
	
	@Override
	public String getName() {
		return "krab";
	}
	
	@Override
	public int getLayer() {
		return 1;
	}
	
	@Override
	public boolean isMovable() {
		return false;
	}
	
	@Override
	public boolean isHeavy() {
		return false;
	}
	
	@Override
	public boolean isSolid() {
		return false;
	}
	
	//Movimento automático do caranguejo, chamado a cada tick.
	@Override
    public void tick() {
        if (getRoom() == null || getPosition() == null) 
        	return;
        
        //Escolhe aleatoriamente mover-se 1 casa para a esquerda ou direita.
        int dx = rnd.nextBoolean() ? 1 : -1;
        Point2D dest = new Point2D(getPosition().getX() + dx, getPosition().getY());

        if (dest.getX() < 0 || dest.getX() > 9) return;

        Room room = getRoom();
        var objs = room.getObjectsAt(dest);

        for (GameObject o : objs) {
        	
        	//Se encontrar um SmallFish → GAME OVER
            if (o instanceof SmallFish) {
                room.getEngine().showGameOverAndRestart();
                return;
            }
            
            //Se encontrar o BigFish ou Armadilha → o caranguejo morre (é removido)
            if (o instanceof BigFish || o instanceof Armadilha) {
                room.removeObject(this);   
                room.updateGUI();
                return;
            }

            //Se tiver algo sólido (exceto parede com buraco) → bloqueia movimento
            if (o.isSolid() && !(o instanceof ParedeBuraco)) {
                return;
            }
        }
        
        //Caso nada impeça, move o caranguejo
        setPosition(dest);
        room.updateGUI();
    }
	
}