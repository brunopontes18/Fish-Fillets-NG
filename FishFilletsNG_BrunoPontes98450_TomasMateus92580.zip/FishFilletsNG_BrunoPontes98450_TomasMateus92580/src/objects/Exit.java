package objects;

import pt.iscte.poo.game.Room;

public class Exit extends GameObject{

	public Exit(Room room) {
		super(room);
	}
	
	@Override
	public String getName() {
		return "exit";
	}
	
	@Override
	public int getLayer() {
		return 1;
	}
	
	@Override
	public boolean isMovable() {
		return false;
	}
	
	@Override
	public boolean isHeavy() {
		return false;
	}
	
	@Override
	public boolean isSolid() {
		return false;
	}
	
}