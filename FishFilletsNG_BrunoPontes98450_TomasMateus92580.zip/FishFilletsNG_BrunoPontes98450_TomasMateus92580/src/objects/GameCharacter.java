package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Point2D;
import pt.iscte.poo.utils.Vector2D;

//Classe abstrata base para personagens do jogo
//Estende GameObject e acrescenta comportamento genérico de movimento em grelha, usando um Vector2D como direção
//Subclasses diretas: SmallFish e BigFish
public abstract class GameCharacter extends GameObject {
	
	//Construtor base de uma personagem
	public GameCharacter(Room room) {
		super(room);
	}
	
	//Movimento genérico de uma personagem na direção dada
	public void move(Vector2D dir) {
		if (dir == null) 
			return;
		if (getPosition()== null || getRoom() == null)
			return;
		
		Point2D current = getPosition();
		Point2D dest = current.plus(dir);
		
		//Limites da grelha
		if (dest.getX() < 0 || dest.getY() < 0 || dest.getX() >= 10 || dest.getY() >= 10)
			return;
		
		//Movimento simples, apenas se a Room considerar a posição válida
		if (getRoom().canMoveTo(dest)) {
			setPosition(dest);
			getRoom().updateGUI();
		}
		
	}
	
	//Personagens são desenhadas numa camada superior em relação à maioria dos objetos
	@Override
	public int getLayer() {
		return 2;
	}
	
}