package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageTile;
import pt.iscte.poo.utils.Point2D;

//Classe base para todos os objetos do jogo.
public abstract class GameObject implements ImageTile{
	
	//Posição do objeto na grelha
	private Point2D position;
	
	//Sala(nível) em que o objeto existe
	private Room room;
	
	//Construtor base que apenas recebe a room onde o objeto será colocado
	public GameObject(Room room) {
		this.room = room;
	}
	
	//Construtor base que recebe a posição inicial da grelha e a room onde ficará
	public GameObject(Point2D position, Room room) {
		this.position = position;
		this.room = room;
	}

	//Define a posição do objeto através da coordenadas, i coordenada X (coluna), j coordenada Y (linha)
	public void setPosition(int i, int j) {
		position = new Point2D(i, j);
	}
	
	public void setPosition(Point2D position) {
		this.position = position;
	}

	//Define a posição que o objeto ocupa na grelha
	@Override
	public Point2D getPosition() {
		return position;
	}
	
	//Devolve a Room onde o objeto se encontra
	public Room getRoom() {
		return room;
	}
	
	//Associa este objeto a uma Room
	public void setRoom(Room room) {
		this.room = room;
	}
	
	//Avalia se o objeto pode ser empurrado/sujeito a gravidade
	public boolean isMovable() {
		return false;
	}
	
	//Avalia se o objeto é considerado pesado (p.e. mata peixe ao cair em cima deles, ...)
	public boolean isHeavy() {
		return false;
	}
	
	//Avalia se o objeto bloqueia movimento de outros objetos/personagens
	public boolean isSolid() {
		return false;
	}
	
}
