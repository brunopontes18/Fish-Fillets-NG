package objects;

import pt.iscte.poo.game.Room;

public class ParedeBuraco extends GameObject{
	
	public ParedeBuraco(Room room) {
		super(room);
	}

	@Override
	public String getName() {
		return "holedWall";
	}

	@Override
	public int getLayer() {
		return 1;
	}
	
	@Override
	public boolean isSolid() {
		return false;
	}

}