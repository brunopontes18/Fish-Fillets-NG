package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Point2D;

public class Rock extends GameObject implements Tickable{

	//Indica se a pedra esteve a cair no tick anterior
	private boolean falling = false;
	
	//Indica se o Caranguejo associado a esta pedra já foi criado
	private boolean krabSpawned = false;
	
	public Rock(Room room){
		super(room);
	}
	
	@Override
	public String getName() {
		return "stone";
	}
	
	@Override
	public int getLayer() {
		return 1;
	}
	
	@Override
	public boolean isMovable() {
		return true;
	}
	
	@Override
	public boolean isHeavy() {
		return true;
	}
	
	//Permite ao jogo verificar se já foi criado um Caranguejo a partir desta pedra
	public boolean hasKrabSpawned() {
		return krabSpawned;
	}
	
	//Modifica o estado do spawn do Caranguejo associado a esta pedra
	//O spawn é controlado pelos peixes quando empurram a pedra horizontalmente
	public void setKrabSpawned(boolean krabSpawned) {
		this.krabSpawned = krabSpawned;
	}

	//Executa o comportamento de gravidade da pedra
	@Override
	public void tick(){
		if (getPosition() == null || getRoom() == null) return;
		
		Point2D pos = getPosition();
		Point2D below = new Point2D(pos.getX(), pos.getY()+ 1);
		Room room = getRoom();
		
		//Se está no fundo do mapa, não pode cair
		if(below.getY() >= 10) { 
			falling = false;
			return;
		}
		
		boolean onlyWaterOrEmpty = true;
		for (GameObject o : room.getObjectsAt(below)) {
			//Após verificar que não é água analisar o comportamento
			if(!(o instanceof Water)) {
				onlyWaterOrEmpty = false;
				
				//Tronco → é destruído com a queda da pedra e é ocupada pela mesma
				if (o instanceof Tronco) {
					room.removeObject(o);
					this.setPosition(below);
					falling = true;
					room.updateGUI();
					
				//Peixe → morte imediata
				} else if (o instanceof SmallFish || o instanceof BigFish) {
					if (room.getEngine() != null)
						room.getEngine().restartLevel();
				}
				
				//Qualquer outro objeto impede a queda
				break;
			}
		}
		
		// Se está tudo livre e é água → a pedra cai normalmente
		if(onlyWaterOrEmpty) {
			setPosition(below);
			falling = true;
			room.updateGUI();
		}
		
	}

}
