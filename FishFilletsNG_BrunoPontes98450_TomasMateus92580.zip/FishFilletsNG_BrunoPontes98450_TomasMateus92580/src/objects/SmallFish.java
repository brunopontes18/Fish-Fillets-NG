package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Vector2D;
import pt.iscte.poo.utils.Point2D;

import java.util.List;

public class SmallFish extends GameCharacter {
	
	//Instância única (singleton)
	private static SmallFish sf = new SmallFish(null);
	
	//Objeto leve atualmente suportado pelo peixe pequeno
	private GameObject supportedObject = null;
	
	//Construtor privado do peixe pequeno
	private SmallFish(Room room) {
		super(room);
	}

	//Instância única do SmallFish
	public static SmallFish getInstance() {
		return sf;
	}
	
	//Nome da imagem associada ao SmallFish
	@Override
	public String getName() {
		return "smallFishLeft";
	}
	
	//Camada de desenho do SmallFish
	@Override
	public int getLayer() {
		return 1;
	}
	
	//Limpa qualquer objeto que o peixe esteja a suportar
	public void clearSupported() {
		supportedObject = null;
	}
	
	//
	@Override
	public void move(Vector2D dir) {
	    
		if (dir == null) 
	    	return;
	    
	    if (getPosition() == null || getRoom() == null) 
	    	return;

	    Point2D current = getPosition();
	    Point2D dest = current.plus(dir);
	 
	    if (dest.getX() < 0 || dest.getY() < 0 || dest.getX() >= 10 || dest.getY() >= 10)
	        return;

	    Room room = getRoom();
	    List<GameObject> destObjects = room.getObjectsAt(dest);
	    
	    //Tratamento da morte do peixe pequeno caso toque no caranguejo
	    for (GameObject o : destObjects) {
	        if (o instanceof Caranguejo) {
	            if (room.getEngine() != null)
	                room.getEngine().showGameOverAndRestart();
	            return;
	        }
	    }
	    
	    //Impedimento da descida para uma casa onde esteja a boia
	    if (dir.getY() > 0) { 
	        for (GameObject o : destObjects) {
	            if (o instanceof Boia) {
	                return;
	            }
	        }
	    }
	    
	    //Se estiver a suportar uma boia, não pode mover-se na vertical
	    if (dir.getY() != 0 && supportedObject instanceof Boia) {
	    	return;
	    }
	    
	    //Bloqueio por objetos pesados no destino (excepto armadilha)
	    for (GameObject o : destObjects) {
	        if (o instanceof Armadilha) 
	        	continue; //SmallFish atravessa a armadilha
	        
	        //Não entra numa casa com objeto pesado
	        if (o.isHeavy()) {
	            return; 
	        }
	    }
	    
	    //Conta quantos objetos leves móveis existem no destino
	    int movableLightCount = 0;
	    GameObject movableLight = null;

	    for (GameObject o : destObjects) {
	        if (o.isMovable() && !o.isHeavy()) {
	            movableLightCount++;
	            movableLight = o;
	        }
	    }
	    
	    //Se houver mais do que um objeto leve, sobrecarga → morte imediata
	    if (movableLightCount > 1) {  
	        if (getRoom().getEngine() != null) 
	        	getRoom().getEngine().showGameOverAndRestart();
	        return;
	    }
	    
	    //Caso não haja objetos leves no destino → tentativa de movimento simples
	    if (movableLightCount == 0) {
	        boolean hasBlocking = false;
	        for (GameObject o : destObjects) { 
	        	//Bloca se for sólido e não for parede com buraco e não for armadilha
	            if ((o.isSolid() && !(o instanceof ParedeBuraco)) && !(o instanceof Armadilha)) {
	                hasBlocking = true;
	                break;
	            }
	        }
	        
	        if (!hasBlocking && room.canMoveTo(dest)) {
	        	//Se estiver a suportar algo, trata esse suporte
	            if (supportedObject != null) {
	                //Se está algo a suportar algo, não pode mover-se na vertical
	            	if (dir.getY() != 0) {
	                    return;
	                } else {
	                	//Movimento horizontal: objeto suportado tenta afundar
	                    if (!supportedObject.isHeavy()) {
	                        Point2D sp = supportedObject.getPosition();
	                        Point2D below = new Point2D(sp.getX(), sp.getY() + 1);
	                        if (below.getY() < 10) {
	                            boolean canSink = true;
	                            for (GameObject o : room.getObjectsAt(below)) {
	                                if (o.isSolid() || o instanceof GameCharacter) { 
	                                	canSink = false; 
	                                	break; 
	                                	}
	                            }
	                            if (canSink) 
	                            	supportedObject.setPosition(below);
	                        }
	                    } else {
	                    	//Se estivesse a supportar pesado → morte 
	                        if (getRoom().getEngine() != null) 
	                        	getRoom().getEngine().showGameOverAndRestart();
	                        return;
	                    }
	                    //Deixa de suportar após movimento horizontal
	                    supportedObject = null;
	                }
	            }
	            //Move o peixe
	            setPosition(dest);
	            room.updateGUI();
	            //Verifica pilha de objetos leves acima
	            room.checkSmallFishOverload();
	        }
	        return;
	    }
	    
	    //Tenta empurrar objeto leve
	    Point2D pushDest = dest.plus(dir);
	    boolean canPush = true;

	    if (pushDest.getX() < 0 || pushDest.getY() < 0 || pushDest.getX() >= 10 || pushDest.getY() >= 10)
	        canPush = false;
	    else {
	        List<GameObject> pushObjs = room.getObjectsAt(pushDest);
	        
	        for (GameObject o : pushObjs) {
	            
	        	//Se o destino é parede com buraco e o objeto empurrado for a taça ou um caranguejo, atravessam o buraco
	            if (o instanceof ParedeBuraco && (movableLight instanceof Taca || movableLight instanceof Caranguejo)) {
	                continue;
	            }
	            
	            //SmallFish não empurra objetos para cima de outros objetos móveis na vertical
	            if (dir.getY() != 0 && o.isMovable()) {
	                canPush = false;
	                break;
	            }
	            
	            //Bloqueio por objetos sólidos ou personagens
	            if (o.isSolid() || o instanceof GameCharacter) {
	                canPush = false;
	                break;
	            }
	        }
	    }

	    //Não empurra bomba se não conseguir movimentar para uma casa livre
	    if (movableLight instanceof Bomba && !canPush) {
	        return;   
	    }
	    
	    //Caso consiga empurrar o objeto
	    if (canPush) { 
	    	//Não deixa empurrar boia para baixo
	    	if (dir.getY() > 0 && movableLight instanceof Boia) {
	    		return;
	    	}
	        
	    	//Move objeto leve
	    	movableLight.setPosition(pushDest);
	        setPosition(dest);
	        
	        //Se a rocha foi empurrada na horizontal, tenta spawnar caranguejo
	        if (dir.getY() == 0 && movableLight instanceof Rock) {
	            Rock r = (Rock) movableLight;
	            if (!r.hasKrabSpawned()) {
	                Point2D krabPos = new Point2D(r.getPosition().getX(), r.getPosition().getY() - 1);
	                if (krabPos.getY() >= 0) {
	                    List<GameObject> above = room.getObjectsAt(krabPos);
	                    boolean free = true;
	                    for (GameObject o : above) {
	                        if (!(o instanceof Water)) { 
	                        	free = false; 
	                        	break; 
	                        	}
	                    }
	                    if (free) {
	                        Caranguejo c = new Caranguejo(room);
	                        c.setPosition(krabPos);
	                        room.addObject(c);
	                        r.setKrabSpawned(true);
	                    }
	                }
	            }
	        }
	        
	        //Se já suportava outro objeto diferente do que acabou de empurrar → morte 
	        if (supportedObject != null && supportedObject != movableLight) {
	            if (getRoom().getEngine() != null) 
	            	getRoom().getEngine().showGameOverAndRestart();
	            return;
	        }
	        
	        //Se está a suportar exatamente o objeto que empurrou, mantém-no em cima
	        if (supportedObject == movableLight) {
	            supportedObject.setPosition(dest);
	        }
	        room.updateGUI();
	        return;
	    }
	    
	    //Se não conseguiu empurrar
	    if (supportedObject == null) {
	    	//Não pode começar a suportar a boia, bomba ou taça
	    	if (movableLight instanceof Boia || movableLight instanceof Bomba || movableLight instanceof Taca) {
	        		return;
	        }
	    	//Passa a suportar o objeto leve
	    	supportedObject = movableLight;
	    	supportedObject.setPosition(dest);
	    	setPosition(dest);
	    	room.updateGUI();
	    	room.checkSmallFishOverload();
	    	return;
	    } else {
	    	//Já suportava algo e tentou interagir com outro objeto leve → morte
	    	if (getRoom().getEngine() != null) 
	    		getRoom().getEngine().showGameOverAndRestart();
	    }
	}
}