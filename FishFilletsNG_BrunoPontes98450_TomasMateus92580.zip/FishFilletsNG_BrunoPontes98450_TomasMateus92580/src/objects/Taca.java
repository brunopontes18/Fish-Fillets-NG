package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Point2D;

public class Taca extends GameObject implements Tickable {

	private boolean falling = false;
	
	public Taca(Room room) {
		super(room);
	}

	@Override
	public String getName() {
		return "cup";
	}

	@Override
	public int getLayer() {
		return 1;
	}
	
	@Override
	public boolean isMovable() {
		return true;
	}
	
	@Override
	public boolean isHeavy() {
		return false;
	}
	
	@Override
	public void tick() {
		if (getPosition() == null || getRoom()== null) return;
		Point2D pos = getPosition();
		Point2D below = new Point2D(pos.getX(), pos.getY() + 1);
		Room room = getRoom();
		
		if (below.getY() >= 10) {
			falling = false; 
			return;
		}
		
		boolean onlyWaterOrEmpty = true;
		for (GameObject o : room.getObjectsAt(below)) {
			if(!(o instanceof Water)) {
				onlyWaterOrEmpty = false;
				break;
			}
		}
		if(onlyWaterOrEmpty) {
			setPosition(below);
			falling = true;
			room.updateGUI();
		} else {
			falling = false;
		}
	}

}