package objects;

public interface Tickable {
	void tick();

}
