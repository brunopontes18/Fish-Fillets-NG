package objects;

import pt.iscte.poo.game.Room;

public class Tronco extends GameObject {

	public Tronco(Room room) {
		super(room);
	}

	@Override
	public String getName() {
		return "trunk";
	}

	@Override
	public int getLayer() {
		return 1;
	}
	
	@Override
	public boolean isMovable() {
		return false;
	}
	
	@Override
	public boolean isHeavy() {
		return false;
	}
	
	@Override
	public boolean isSolid() {
		return true;
	}

}