package pt.iscte.poo.game;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import objects.SmallFish;
import objects.Tickable;
import objects.Water;
import objects.BigFish;
import objects.GameCharacter;
import objects.GameObject;
import objects.ParedeBuraco;
import objects.Caranguejo;
import objects.Exit;
import objects.Armadilha;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.observer.Observed;
import pt.iscte.poo.observer.Observer;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;
import pt.iscte.poo.utils.Vector2D;

public class GameEngine implements Observer {
	
	//Conjunto de salas de jogo, indexadas pelo nome do ficheiro
	private Map<String,Room> rooms;
	//Sala(nível) atual do jogo
	private Room currentRoom;
	//Último tick de tempo já processado
	private int lastTickProcessed = 0;
	//Peixe atualmente controlado pelo jogador
	private GameCharacter activeFish;
	//Flags que indicam se os dois peixes já chegaram à saída
	private boolean smallFinished = false;
	private boolean bigFinished = false;
	//Nome do ficheiro onde são guardados os highscores
	private static final String HIGHSCORE_FILE = "highscores.txt";
	//Instante (em ms) em que o jogo começou (para cálculo da duração total)
	private long startTime;
	//Número total de movimentos realizados pelo jogador desde o início do jogo
	private int moveCount = 0;
	
	//Cria o motor do jogo, carrega todos os níveis e inicializa o primeiro nível (room0.txt), posicionando os peixes nas posições lidas do ficheiro
	public GameEngine() throws FileNotFoundException {
		rooms = new HashMap<String,Room>();
		loadGame();
		currentRoom = rooms.get("room0.txt");
		
		//Inicializar o SmallFish na sala atual
		SmallFish sf = SmallFish.getInstance();
		sf.setRoom(currentRoom);
		if (currentRoom.getSmallFishStartingPosition() != null) {
			sf.setPosition(currentRoom.getSmallFishStartingPosition());
		}
		
		//Inicializar o BigFish na sala atual
		BigFish bf = BigFish.getInstance();
		bf.setRoom(currentRoom);
		if (currentRoom.getBigFishStartingPosition() != null) {
			bf.setPosition(currentRoom.getBigFishStartingPosition());
		}
		
		activeFish = sf;
		smallFinished = false;
		bigFinished = false;
		moveCount = 0;
		startTime = System.currentTimeMillis();
		updateGUI();
		updateLevelMessage();
	}

	//Lê todos os ficheiros de salas da pasta "rooms" e cria um mapa nome-do-ficheiro → Room
	private void loadGame() throws FileNotFoundException {
		File[] files = new File("./rooms").listFiles();
		for(File f : files) {
			if(f.getName().endsWith(".txt"))
			rooms.put(f.getName(),Room.readRoom(f,this));
		}
	}
	
	//Estrutura auxiliar para guardar um registo de highscore: nome do jogador, tempo e número de movimentos
	private static class Score {
		String name;
		long timeMS;
		int moves;
		
		Score (String name, long timeMs, int moves) {
			this.name = name;
			this.timeMS = timeMs;
			this.moves = moves;
		}
	}
	
	//Método chamado pelo mecanismo de Observer (ImageGUI). 
	//É aqui que: lemos a tecla premida, tratamos mudança de peixe (SPACE) e restart (R), 
	//movemos o peixe ativo nas setas, processamos gravidade/ticks enquanto o tempo avança e verificamos condição de vitória
	@Override
	public void update(Observed source) {

		if (ImageGUI.getInstance().wasKeyPressed()) {
			int k = ImageGUI.getInstance().keyPressed();
			
			//Tecla R recomeça o nível ao ser pressionada
			if (k == java.awt.event.KeyEvent.VK_R) {
				restartLevel();
				return;
			}
			
			//Tecla SPACE faz com que troquemos o nosso peixe ativo
			if (k == java.awt.event.KeyEvent.VK_SPACE) {
				if(activeFish == SmallFish.getInstance()) {
					if(!bigFinished)
						activeFish = BigFish.getInstance();
			} else {
					if(!smallFinished)
						activeFish = SmallFish.getInstance();
				}
			} 
			else {
				//Tentativa de mover o peixe ativo com as setas
			    try {
			        Vector2D dir = Direction.directionFor(k).asVector();
			        
			        //Guardamos a posição antes do movimento (para saber se realmente mexeu)
			        Point2D before = activeFish.getPosition();
			        if (before != null)
			            before = new Point2D(before.getX(), before.getY());

			        activeFish.move(dir);
			        moveCount++;
			        updateLevelMessage();
			        
			        //Caso o peixe se tenha mexido, mexemos também o caranguejo
			        Point2D after = activeFish.getPosition();
			        if (before != null && after != null && !before.equals(after)) {
			            moveKrabsAfterFishMove();
			        }

			    } catch (IllegalArgumentException e) {
			    	//Tecla não corresponde a direção, ignorar
			    }
			}
			
			//Processamento de ticks até à contagem atual da GUI(gravidade e outros Tickable)
			int t = ImageGUI.getInstance().getTicks();
			while (lastTickProcessed < t) {
				if (currentRoom != null)
	                currentRoom.applyGravity();

	            processTick();
	            lastTickProcessed++;
			}
			checkVictory();
		}
		ImageGUI.getInstance().update();
	}
	
	//Executa o método tick() de todos os objetos que implementam a interface Tickable na sala atual
	private void processTick() {
		List<GameObject> tickables = currentRoom.select(o -> o instanceof Tickable);
		for (GameObject o : tickables) {
			((Tickable)o).tick();
			
		}
	}
	
	//Atualiza a GUI com as imagens da sala atual
	public void updateGUI() {
		if(currentRoom!=null) {
			ImageGUI.getInstance().clearImages();
			ImageGUI.getInstance().addImages(currentRoom.getObjects());
			
		}
	}
	
	//Movimento automático dos caranguejos após um movimento de um dos peixes.
	//Cada caranguejo tenta mover-se aleatoriamente para a esquerda/direita:
	//mata o SmallFish se o atingir, morre se colidir com o BigFish ou com uma Armadilha, 
	//não atravessa paredes, objetos sólidos ou outros caranguejos
	private void moveKrabsAfterFishMove() {
	    if (currentRoom == null) return;

	    List<GameObject> krabs = currentRoom.select(o -> o instanceof Caranguejo);
	    Random rnd = new Random();

	    for (GameObject go : new ArrayList<>(krabs)) {
	        Caranguejo krab = (Caranguejo) go;
	        if (krab.getPosition() == null) continue;

	        int dirX = rnd.nextBoolean() ? -1 : 1;
	        Point2D pos = krab.getPosition();
	        Point2D dest = new Point2D(pos.getX() + dirX, pos.getY());

	        if (dest.getX() < 0 || dest.getX() >= 10)
	            continue;

	        List<GameObject> destObjs = currentRoom.getObjectsAt(dest);

	        boolean blocked = false;
	        boolean killSmall = false;
	        boolean krabDies = false;

	        for (GameObject o : destObjs) {
	        	//Água, Parede com buraco e a saída não bloqueiam diretamente
	            if (o instanceof Water || o instanceof ParedeBuraco || o instanceof Exit)
	                continue; 

	            if (o instanceof SmallFish) {
	                killSmall = true;
	            } else if (o instanceof BigFish || o instanceof Armadilha) {
	                krabDies = true;
	            } else if (o instanceof Caranguejo) {
	                blocked = true; 
	                break;
	            } else if (o.isSolid() || o.isMovable()) {
	                blocked = true;
	                break;
	            }
	        }

	        if (blocked) continue;

	        if (krabDies) {
	            currentRoom.removeObject(krab);
	        } else {
	            krab.setPosition(dest);
	        }

	        if (killSmall) {
	            if (currentRoom.getEngine() != null)
	                currentRoom.getEngine().showGameOverAndRestart();
	            return;
	        }
	    }

	    currentRoom.updateGUI();
	}
	
	//Recomeça o nível atual: recarrega o ficheiro da room, reinicializa peixes e estado de fim de nível
	public void restartLevel() {
		
		if (currentRoom == null) return;
		String name = currentRoom.getName();
		File f = new File("./rooms/" + name);
		Room newRoom = Room.readRoom(f, this);
		rooms.put(name, newRoom);
		currentRoom = newRoom;
		SmallFish.getInstance().setRoom(currentRoom);
		BigFish.getInstance().setRoom(currentRoom);
		SmallFish.getInstance().clearSupported();
		BigFish.getInstance().clearSupported();
		
		smallFinished = false;
		bigFinished = false;
		activeFish = SmallFish.getInstance();
		
		moveCount = 0;
		updateGUI();
		updateLevelMessage();
			
	}
	
	//Mostra mensagem de GAME OVER e reinicia o nível atual
	public void showGameOverAndRestart() {
		ImageGUI.getInstance().showMessage("GAME OVER", "GAME OVER");
		restartLevel();
	}
	
	//Verifica se algum dos peixes entrou na saída do nível. Quando um peixe chega à saída: é removido da room, 
	//a sua posição passa a null, a flag correspondente (smallFinished/bigFinished) fica true 
	public void checkVictory() {
		if (currentRoom == null) return;
		
		SmallFish sf = SmallFish.getInstance();
		BigFish bf = BigFish.getInstance();
		
		if(!smallFinished && sf.getPosition() != null && currentRoom.isExitAt(sf.getPosition())) {
			smallFinished = true;
			currentRoom.removeObject(sf);
			sf.setPosition(null);
		}
		
		if(!bigFinished && bf.getPosition() != null && currentRoom.isExitAt(bf.getPosition())) {
			bigFinished = true;
			currentRoom.removeObject(bf);
			bf.setPosition(null);
		}
		
		//Quando ambos tiverem terminado, avança para o próximo nível
		if(bigFinished && smallFinished) {
			goToNextLevel();
		}
		
	}
	
	//Carrega o próximo nível (roomN+1.txt). Se não existir próximo nível, invoca gameCompleted() 
	//Caso exista: Carrega a nova Room. Reposiciona SmallFish e BigFish nas posições iniciais 
	//Limpa estados de suporte e flags de fim de nível. Reinicia a contagem de movimentos para o novo nível
	private void goToNextLevel() {
	    if (currentRoom == null) return;

	    String currentName = currentRoom.getName();   
	    int idx = extractRoomIndex(currentName);      
	    String nextName = "room" + (idx + 1) + ".txt";

	    File f = new File("./rooms/" + nextName);
	    if(!f.exists()) {
	    	gameCompleted();
	    	return;
	    }
	    
	    Room next = Room.readRoom(f, this);
	    rooms.put(nextName, next);
	    currentRoom = next;
	    
	    SmallFish sf = SmallFish.getInstance();
	    BigFish bf = BigFish.getInstance();

	    SmallFish.getInstance().setRoom(currentRoom);
	    BigFish.getInstance().setRoom(currentRoom);
	    SmallFish.getInstance().clearSupported();
	    BigFish.getInstance().clearSupported();

	    sf.setRoom(currentRoom);
	    bf.setRoom(currentRoom);
	    sf.clearSupported();
	    bf.clearSupported();
	    smallFinished = false;
	    bigFinished = false;
	    activeFish = sf;
	    lastTickProcessed = ImageGUI.getInstance().getTicks();
	    
	    moveCount = 0;
	    updateGUI();
	    updateLevelMessage();
	}

	//Extrai o índice do nível a partir do nome do ficheiro, por exemplo "room2.txt" → 2
	private int extractRoomIndex(String filename) {
	    String digits = filename.replaceAll("\\D", "");
	    if (digits.isEmpty())
	        return 0;
	    return Integer.parseInt(digits);
	}
	
	//Chamado quando não existem mais níveis a seguir ao atual. 
	//Calcula o tempo total de jogo, pergunta o nome ao jogador, atualiza a lista de highscores (mantendo apenas o top 10)
	//Apresenta a tabela
	private void gameCompleted() {
	    long endTime = System.currentTimeMillis();
	    long totalTimeMs = endTime - startTime;
	 
	    String name = ImageGUI.getInstance().showInputDialog("Fim do jogo", "Introduz o teu nome para a tabela de highscores:");
	    if (name == null || name.isBlank())
	        name = "Jogador";

	    List<Score> scores = loadHighscores();
	    scores.add(new Score(name, totalTimeMs, moveCount));
	    scores.sort((a, b) -> {
	        int cmp = Long.compare(a.timeMS, b.timeMS);
	        if (cmp != 0) return cmp;
	        return Integer.compare(a.moves, b.moves);
	    });

	    if (scores.size() > 10) {
	        scores = new ArrayList<>(scores.subList(0, 10));
	    }

	    saveHighscores(scores);

	    StringBuilder sb = new StringBuilder();
	    sb.append("TOP 10 HIGHSCORES\n\n");
	    for (int i = 0; i < scores.size(); i++) {
	        Score s = scores.get(i);
	        double seconds = s.timeMS / 1000.0;
	        sb.append(String.format("%2d. %-12s  Tempo: %6.2fs  Movimentos: %d%n", i+1, s.name, seconds, s.moves));
	    }

	    ImageGUI.getInstance().showMessage("Highscores", sb.toString()); 
	}
	
	//Lê do ficheiro de highscores todas as entradas previamente guardadas. 
	//Faz return da lista scores lidos (pode ser vazia)
	private List<Score> loadHighscores() {
	    List<Score> scores = new ArrayList<>();

	    File f = new File(HIGHSCORE_FILE);
	    if (!f.exists())
	        return scores; 

	    try (BufferedReader br = new BufferedReader(new FileReader(f))) {
	        String line;
	        while ((line = br.readLine()) != null) {
	            line = line.trim();
	            if (line.isEmpty()) continue;
	            String[] parts = line.split(";");
	            if (parts.length != 3) continue;
	            String name = parts[0];
	            long timeMs = Long.parseLong(parts[1]);
	            int moves = Integer.parseInt(parts[2]);
	            scores.add(new Score(name, timeMs, moves));
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return scores;
	}
	
	//Guarda a lista de highscores no ficheiro HIGHSCORE_FILE, um registo por linha
	private void saveHighscores(List<Score> scores) {
	    try (BufferedWriter bw = new BufferedWriter(new FileWriter(HIGHSCORE_FILE))) {
	        for (Score s : scores) {
	            bw.write(s.name + ";" + s.timeMS + ";" + s.moves);
	            bw.newLine();
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	//Atualiza a mensagem da barra de estado da janela com: o número do nível atual e o número de movimentos já efetuados
	private void updateLevelMessage() {
	    if (currentRoom == null) return;

	    String name = currentRoom.getName();  
	    int idx = extractRoomIndex(name);     
	    int levelNumber = idx + 1;

	    ImageGUI.getInstance().setStatusMessage("Good luck! - Level " + levelNumber + " | Moves: " + moveCount);
	}

}
