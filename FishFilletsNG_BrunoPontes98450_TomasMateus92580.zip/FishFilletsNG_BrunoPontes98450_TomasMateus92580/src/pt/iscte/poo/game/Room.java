package pt.iscte.poo.game;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

import objects.Water;
import objects.Ancora;
import objects.Armadilha;
import objects.BigFish;
import objects.Boia;
import objects.Bomba;
import objects.Caranguejo;
import objects.GameCharacter;
import objects.GameObject;
import objects.ParedeBuraco;
import objects.Rock;
import objects.SmallFish;
import objects.SteelHorizontal;
import objects.SteelVertical;
import objects.Taca;
import objects.Tronco;
import objects.Wall;
import objects.Exit;
import pt.iscte.poo.utils.Point2D;

//Representa uma "sala" ou nível do jogo. Responsabilidades principais: Guardar e gerir todos os GameObject presentes no nível
//Ler o ficheiro de configuração (roomN.txt) e criar os objetos.
//Fornecer operações de consulta (objetos numa posição, pode-mover-para, etc.).
//Aplicar gravidade aos objetos móveis.
//Gerir eventos especiais como explosões da bomba
public class Room {
	
	private List<GameObject> objects;
	private String roomName;
	private GameEngine engine;
	private Point2D smallFishStartingPosition;
	private Point2D bigFishStartingPosition;
	
	//Cria uma room vazia. Está inicializada
	public Room() {
		objects = new ArrayList<GameObject>();
	}
	
	//Define o nome interno da sala
	private void setName(String name) {
		roomName = name;
	}
	
	//Nome da sala (ficheiro)
	public String getName() {
		return roomName;
	}
	
	//Associa esta room a um GameEngine
	private void setEngine(GameEngine engine) {
		this.engine = engine;
	}

	//Adiciona um objeto à lista desta room e pede à engine que atualize a GUI
	public void addObject(GameObject obj) {
		objects.add(obj);
		engine.updateGUI();
	}
	
	//Adiciona um objeto numa determinada posição e atualiza a GUI
	public void addObject (GameObject obj, Point2D p) {
		obj.setPosition(p);
		objects.add(obj);
		engine.updateGUI();
	}
	
	//Remove um objeto da room e atualiza a GUI
	public void removeObject(GameObject obj) {
		objects.remove(obj);
		engine.updateGUI();
	}
	
	//Lista de todos os GameObject presentes na room
	public List<GameObject> getObjects() {
		return objects;
	}
	
	//Devolve o primeiro objeto encontrado numa dada posição (ou null se não houver).
	//Nota: se existirem vários objetos na mesma posição, apenas o primeiro da lista é retornado
	public GameObject getObjectAt (Point2D p) {
		for (GameObject o: objects) {
			if(o.getPosition().equals(p))
				return o;
			
		}
		return null;
	}
	
	//Define a posição inicial do SmallFish para esta room
	public void setSmallFishStartingPosition(Point2D heroStartingPosition) {
		this.smallFishStartingPosition = heroStartingPosition;
	}
	
	//Posição inicial do SmallFish
	public Point2D getSmallFishStartingPosition() {
		return smallFishStartingPosition;
	}
	
	//Define a posição inicial do BigFish para esta room
	public void setBigFishStartingPosition(Point2D heroStartingPosition) {
		this.bigFishStartingPosition = heroStartingPosition;
	}
	
	//Posição inicial do BigFish
	public Point2D getBigFishStartingPosition() {
		return bigFishStartingPosition;
	}
	
	//Cria o objeto correspondente a um dado carácter do ficheiro de nível e adiciona-o à room.
	//c símbolo lido do ficheiro (ex: 'W', 'S', 'B', ...)
	//r room onde o objeto será colocado
	//p posição do objeto na grelha
	public static void addObjectToRoom(char c, Room r, Point2D p) {
		
		GameObject go = null;
		switch (c) {
			case ' ' -> go = new Water(r);
			case 'E' -> go = new Exit(r);
			case 'W' -> go = new Wall(r);
			case 'X' -> go = new ParedeBuraco(r);
			case 'R' -> go = new Rock(r);
			case 'H' -> go = new SteelHorizontal(r);
			case 'V' -> go = new SteelVertical(r);
			case 'C' -> go = new Taca(r);
			case 'c' -> go = new Caranguejo(r);
			case 'P' -> go = new Boia(r);
			case 'A' -> go = new Ancora(r);
			case 'b' -> go = new Bomba(r);
			case 'T' -> go = new Armadilha(r);
			case 'Y' -> go = new Tronco(r);
			
			//Peixe grande (singleton)
			case 'B' -> {
				BigFish bf = BigFish.getInstance();
				bf.setRoom(r);
				bf.setPosition(p);
				r.setBigFishStartingPosition(p);
				r.addObject(bf);
				return;
			}
			
			//Peixe pequeno (singleton)
			case 'S' -> {
				SmallFish sf = SmallFish.getInstance();
				sf.setRoom(r);
				sf.setPosition(p);
				r.setSmallFishStartingPosition(p);
				r.addObject(sf);
				return;
			}
			default -> throw new RuntimeException("Invalid char; " + c);
			
		}
		
		go.setPosition(p);
		r.addObject(go);
		
		
}
	//Lê um ficheiro de nível (roomN.txt) e constroi a respetiva Room.
	//Para cada carácter da grelha cria o objeto correspondente e, no fim, garante que há sempre água em todas as posições (caso nenhum objeto tenha sido colocado numa determinada célula)
	public static Room readRoom(File f, GameEngine engine){
		
		Room r = new Room();
		r.setEngine(engine);
		r.setName(f.getName());
		
		try (Scanner fscn = new Scanner(f)) {
		
			int y = 0;
			while (fscn.hasNextLine()) {
				String line = fscn.nextLine();
				int x = 0;
				for (char c : line.toCharArray()) {
					addObjectToRoom(c,r, new Point2D(x,y));
					++x;
				}
				++y;
			
			}	
			
			//Garante que todas as células têm pelo menos água (Water)
			for (int yy = 0; yy < 10; yy++) {
			    for (int xx = 0; xx < 10; xx++) {
			        Point2D p = new Point2D(xx, yy);
			        boolean hasWater = false;
			        for (GameObject o : r.getObjectsAt(p)) {
			            if (o instanceof Water) {
			                hasWater = true;
			                break;
			            }
			        }
			        if (!hasWater) {
			            Water w = new Water(r);
			            w.setPosition(p);
			            r.addObject(w);
			        }
			    }
			}
		
		} catch (FileNotFoundException e) {
			//Não deve acontecer, uma vez que os ficheiros são conhecidos à partida. Se acontecer, a Room ficará vazia
		}
		return r;
		
	}
	
	//Verifica se uma posição é válida para um personagem se mover. 
	//Nesta implementação a posição é considerada bloqueada se tiver paredes, tubos de aço ou outro peixe
	public boolean canMoveTo(Point2D p) {
		if (p.getX() < 0 || p.getY() < 0 || p.getX() >= 10 || p.getY() >= 10)
			return false;
		
		for(GameObject obj: objects) {
			if(obj.getPosition().equals(p)) {
				if(obj instanceof Wall || obj instanceof SteelHorizontal || obj instanceof SteelVertical || obj instanceof BigFish || obj instanceof SmallFish )
					return false;
			}
		}
		return true;
	}
	
	//Seleciona todos os objetos que satisfazem um dado predicado e cria uma lista com os mesmos
	public List<GameObject> select(Predicate<GameObject> p){
		List <GameObject> l = new ArrayList<>();
		for (GameObject o : objects) {
			if (p.test(o)) {
				l.add(o);
			}
		}
		return l;
	}
	
	//Devolve todos os objetos presentes numa determinada posição
	public List<GameObject> getObjectsAt(Point2D p){
		List<GameObject> list = new ArrayList<>();
		for (GameObject o : objects) {
			if (o.getPosition() != null && o.getPosition().equals(p))
				list.add(o);
		}
		return list;
	}
	
	//Engine associada a este Room
	public GameEngine getEngine() {
		return this.engine;
	}
	
	//Verifica se é possível colocar um novo objeto numa dada posição. 
	//A posição é considerada inválida se: Estiver fora da grelha. Tiver objetos sólidos. Tiver personagens GameCharacter 
	public boolean canPlaceObjectAt(Point2D p) {
		if(p.getX() < 0 || p.getY() < 0 || p.getX() >= 10 || p.getY() >= 10)
			return false;
		for (GameObject o : getObjectsAt(p)) {
			if(o.isSolid()) return false;
			if(o instanceof objects.GameCharacter) return false;
		}
		return true;
	}
	
	//Faz um objeto "afundar" um quadrado (se possível). 
	//Usado em algumas situações pontuais onde é preciso simular gravidade de um único objeto
	public void skinObject(GameObject obj) {
		if(obj == null || obj.getPosition() == null) return;
		Point2D pos = obj.getPosition();
		Point2D below = new Point2D(pos.getX(), pos.getY()+1);
		if (below.getY()<0 || below.getY() >= 10) return;
		boolean canMove = true;
		for (GameObject o : getObjectsAt(below)) {
			if(o.isSolid() || o instanceof GameCharacter) {
				canMove = false;
				break;
			}
		}
		
		if (canMove) {
			obj.setPosition(below);
			updateGUI();
		}
	}
	
	//Remove todos os objetos numa posição e troca por água
	public void replaceWithWater(Point2D p) {
		List<GameObject> here = new ArrayList<GameObject>(getObjectsAt(p));
		for (GameObject o : here) {
			removeObject(o);
		}	
		Water w = new Water(this);
		w.setPosition(p);
		addObject(w);
		updateGUI();
		
	}
	
	//Realiza a explosão de uma bomba centrada no ponto c. São afetadas as posições: centro, cima, baixo, esquerda e direita. 
	//Todos os objetos nessas casas são removidos (exceto água). Se algum peixe for atingido, o nível termina em GAME OVER.
	public void explodeAt(Point2D c) {
		List<Point2D> toCheck = new ArrayList<Point2D>();
		toCheck.add(c);
		toCheck.add(new Point2D(c.getX()-1, c.getY()));
		toCheck.add(new Point2D(c.getX()+1, c.getY()));
		toCheck.add(new Point2D(c.getX(), c.getY()-1));
		toCheck.add(new Point2D(c.getX(), c.getY()+1));

		
		boolean fishKilled = false;
		
		for (Point2D p : toCheck) {
			if(p.getX() < 0 || p.getY() <0 || p.getX() >= 10 || p.getY() >= 10) continue;
			List<GameObject> here = new ArrayList<>(getObjectsAt(p));
			for (GameObject o : here) {
				if (o instanceof SmallFish || o instanceof BigFish) {
					fishKilled = true;
				} else if (!(o instanceof Water)){
					removeObject(o);
				}
			}
			Water w = new Water(this);
			w.setPosition(p);
			addObject(w);
		}
		updateGUI();
		
		if (fishKilled && engine != null) {			
			engine.showGameOverAndRestart();
		}
		
	}
	
	//Verifica se o SmallFish está a suportar mais do que um objeto leve (um diretamente acima e outro por cima desse)
	//Caso se verifique causa morte
	public void checkSmallFishOverload() {
	    SmallFish sf = SmallFish.getInstance();
	    
	    if (sf.getRoom() != this || sf.getPosition() == null)
	        return;
	    
	    Point2D p = sf.getPosition();
	    
	    //Primeiro quadrado acima do peixe
	    Point2D p1 = new Point2D(p.getX(), p.getY() - 1);
	    if (p1.getY() < 0) return;
	    
	    GameObject firstLight = null;
	    for (GameObject o : getObjectsAt(p1)) {
	        if (o.isMovable() && !o.isHeavy()) {
	            firstLight = o;
	            break;
	        }
	    }
	    if (firstLight == null) return;
	    
	    //Segundo quadrado acima do peixe
	    Point2D p2 = new Point2D(p1.getX(), p1.getY() - 1);
	    if (p2.getY() < 0) return;
	    
	    for (GameObject o : getObjectsAt(p2)) {
	        if (o.isMovable() && !o.isHeavy()) {
	            if (engine != null)
	                engine.showGameOverAndRestart();
	            return;
	        }
	    }
	}
	
	//Aplica gravidade a todos os objetos móveis (âncoras, taças, bombas, caranguejos).
	public void applyGravity() {
	    
		//Seleciona objetos móveis sujeitos à gravidade
		List<GameObject> mobiles = select(o -> o instanceof Ancora || o instanceof Taca || o instanceof Bomba || o instanceof Caranguejo);
	    
	    //Ordena de baixo para cima (para evitar que objetos se atravessem)
	    mobiles.sort((a, b) -> Integer.compare(b.getPosition().getY(), a.getPosition().getY()));
	
	    for (GameObject obj : mobiles) {
	        if (obj.getPosition() == null)
	        	continue;
	        
	        Point2D pos   = obj.getPosition();
	        Point2D below = new Point2D(pos.getX(), pos.getY() + 1);
	        
	        //Limite inferior da grelha
	        if (below.getY() >= 10) {
	        	if (obj instanceof Bomba) {
	        		((Bomba)obj).resetFalling();
	        	}
	        	continue;
	        }
	
	        List<GameObject> objsBelow = getObjectsAt(below);
	
	        boolean onlyWater = true;
	        boolean hasHoleWall = false;
	        boolean hasSolidNonFish = false;
	        boolean hasFish = false;
	        boolean hasTrunk = false;
	
	        for (GameObject o : objsBelow) {
	
	            if (o instanceof Water)
	                continue;
	            
	            onlyWater = false;
	            
	            if (o instanceof ParedeBuraco) {
	                hasHoleWall = true;
	                continue;
	            }
	            
	            if (o instanceof SmallFish || o instanceof BigFish) {
	            	hasFish = true;
	            	continue;
	            }
	            
	            if (o instanceof Tronco) {
	            	hasTrunk = true;
	            	hasSolidNonFish = true;
	            	continue;
	            }
	            
	            hasSolidNonFish = true;
	        }
	        
	        //Caso 1: só água - objeto desde uma posição
	        if (onlyWater) {
	            obj.setPosition(below);   
	            if (obj instanceof Bomba) {
	                ((Bomba) obj).markFalling();
	            }
	            continue;
	        }
	        
	        //Caso 2: há tronco imediatamente abaixo e o objeto é pesado → tronco é destruído
	        if (hasTrunk && obj.isHeavy()) {
	        	for (GameObject o : new ArrayList<>(objsBelow)) {
	        		if (o instanceof Tronco) {
	        			removeObject(o);
	        		}
	        	}
	        	obj.setPosition(below);
	        	if (obj instanceof Bomba) {
	        		((Bomba)obj).markFalling();
	        	}
	        	continue;
	        }
	        
	        //Tratamento da bomba
	        if (obj instanceof Bomba) {
	            Bomba b = (Bomba) obj;
	            
	            //Bomba ao cair sobre uma parede com buraco → destrói a parede e troca por água
	            if (hasHoleWall && b.wasFalling()) {
	                replaceWithWater(below);
	                removeObject(b);
	                continue;
	            }
	            
	            //Bomba caiu e bateu em algo sólido(não peixe) → Explode na posição atual
	            if (b.wasFalling() && hasSolidNonFish) {
	                explodeAt(pos);
	                removeObject(b);
	                continue;
	            }
	            
	            //Caso contrário, parou de cair/ficou estável
	            b.resetFalling();
	            continue;
	        }
	        
	        //Objetos pesados que caem em cima de peixes → GAME OVER!!
	        if (obj.isHeavy() && hasFish) {
	        	if (engine != null) {
	        		engine.showGameOverAndRestart();
	        	}
	        	return;
	        }
	        
	        
	    }
	    //Verifica se o SmallFish está a suportar demasiados objetos
	    checkSmallFishOverload();
	    updateGUI();
	}
	
	//Dá return true caso exista uma saída Exit na posição dada
	public boolean isExitAt(Point2D p) {
		for(GameObject o : getObjectsAt(p)) {
			if (o instanceof Exit)
				return true;
		}
		return false;
	}
	
	//Método para atualizar a GUI a partir da Room
	public void updateGUI() {
		//Atualização concreta é feita pelo GameEngine.updateGUI()
	}
}